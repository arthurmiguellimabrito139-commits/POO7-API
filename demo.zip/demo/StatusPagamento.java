package poo.demo;

enum StatusPagamento {
    PENDENTE,
    APROVADO,
    RECUSADO,
    CANCELADO;
}
